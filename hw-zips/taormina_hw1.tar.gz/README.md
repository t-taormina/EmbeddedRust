# Fake Pi Homework 1

Tyler Taormina - taormina@pdx.edu

## Write-up
For this home work I really didn't have to do much. I have Debian installed 
on both my home desktop and Thinkpad so the instructions provided on the hw1
canvas page worked seamlessly. I have used QEMU in the past but only through 
virt-manager. Virt-manager does seem to use both QEMU and KVM, but I could be 
mistaken. This would also only be for running different operating systems using
the same architecture as my host machines (x86-64). I am happy to have learned 
a way to emulate some different hardware and will be definitely spend sometime 
seeing what all I can do with this. Really looking forward to the rest of this 
class.
